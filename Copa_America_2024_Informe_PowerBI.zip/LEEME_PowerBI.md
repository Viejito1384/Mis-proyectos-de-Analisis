# Paquete Power BI · Copa América 2024

## Importar datos
1. En Power BI Desktop, importe cada CSV desde **Obtener datos > Texto/CSV**.
2. No combine estos archivos como una sola tabla: tienen distintos esquemas. También puede usar **Obtener datos > Carpeta** y cargar cada consulta por separado.
3. Use `Medidas_DAX.txt` para crear las medidas; importe `Tema_PowerBI.json` desde **Ver > Temas > Examinar temas**.

## Páginas recomendadas
- **Resumen del torneo:** tarjetas de partidos, goles y goles/partido; goles por fase; goles a favor/en contra por selección.
- **Colombia:** tarjetas de goles y porterías a cero; tabla de grupos; goles por anotador; marcadores partido a partido.
- **Final y pases:** resumen de pases por jugador, mapa espacial usando `Pases_Colombia_Final.csv` (XInicio/YInicio y XFin/YFin) y pases progresivos por jugador.
- **Anotadores:** tabla de goles con fase/fecha si se relaciona `Goles_Anotadores[IdPartido]` con `Partidos[IdPartido]`.

## Relaciones sugeridas
- `Partidos[IdPartido]` 1:* `Goles_Anotadores[IdPartido]`
- `Partidos[IdPartido]` 1:* `Pases_Colombia_Final[IdPartido]`
- `Resumen_Selecciones[Equipo]` y `Resumen_Eventos_Selecciones[Equipo]` representan una fila por selección.
- No una `Tabla_Fase_Grupos` a `Resumen_Selecciones` por equipo si se requiere contexto de varios grupos; filtre por Grupo en esa tabla.

## Convenciones y límites de interpretación
- Los goles y marcadores proceden del marcador final de cada partido en StatsBomb Open Data; no incluyen tiros de tandas de penales.
- El resumen W-D-L de `Resumen_Selecciones.csv` registra el marcador del partido, no el resultado de una tanda.
- Pase completado se identifica con `pass_outcome` vacío en StatsBomb.
- Pase progresivo es una métrica derivada para este análisis, no un campo oficial StatsBomb: avance neto en X de al menos 10 m en campo propio, 15 m si cruza la mitad y 5 m desde campo rival; solo pases completados.
- Los datos son de StatsBomb Open Data y pueden tener disponibilidad/cobertura distinta de otras fuentes. Valores de xG son los del proveedor y solo se incluyen si están disponibles.
- La clasificación de grupos ordena por puntos, diferencia y goles a favor; no aplica el desempate por enfrentamiento directo.
